#include <stdio.h>

#ifndef _WIN32		/* if not define _WIN32 than, we are in unix like system.	*/
#include <fcntl.h>
#include <unistd.h>

#else				/* else we are in windows.*/
#include <windows.h>
#endif

#define BUFF_SIZE 512	

#ifdef _WIN32		/* for win32 */
int main(int argc, char *argv[])
{
	int counter;
	int Write_return;
	int Read_return;
	char Buffer[BUFF_SIZE * 2] = {0x00};								
	DWORD Get;	
	HANDLE hDevice;
	HANDLE hFile;
	HANDLE chainloader;
	HANDLE chain;
	
	hDevice = CreateFile(
        TEXT("\\\\.\\PHYSICALDRIVE0"),
        GENERIC_READ | GENERIC_WRITE ,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        0);
	hFile = CreateFile(
        "mbr.bak",
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        CREATE_ALWAYS,
        0,
        0);	
	chainloader = CreateFile(
        "chainloader",
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        0);		
	chain = CreateFile(
        "chainloader.bin",
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        CREATE_ALWAYS,
        0,
        0);	
	if (INVALID_HANDLE_VALUE ==  hDevice){
		printf("open disk fail\n%d\n", GetLastError());
		return -1;
	}
	if (INVALID_HANDLE_VALUE ==  hFile){
		printf("open mbr fail\n%d\n", GetLastError());
		return -1;
	}
	
	
/***
		Read two secotor of the disk.
***/
	Read_return = ReadFile(
		hDevice,
		Buffer,
		BUFF_SIZE,
		&Get,
		NULL);
	if(Read_return == FALSE) {
		printf("read fail \n%d\n", GetLastError());
		return -1;
	}
	
	Read_return = ReadFile(
		hDevice,
		Buffer + BUFF_SIZE,
		BUFF_SIZE,
		&Get,
		NULL);
	if(Read_return == FALSE ) {
		printf("read fail \n%d\n", GetLastError());
		return -1;
	}
	
/** 
		save two sector to file named mbr.bak
**/
	Write_return = WriteFile(
		hFile,
		Buffer,
		BUFF_SIZE * 2,
		&Get,
		NULL);
	if(Write_return == FALSE) {
		printf("write fail \n%d\n", GetLastError());
		return -1;
	}
	
/******************************************************


******************************************************/
	for (counter = 0; counter < 512; counter++) {
		Buffer[counter + 512] = Buffer[counter];
	}
	
	Read_return = ReadFile(
		chainloader,
		Buffer,
		BUFF_SIZE,
		&Get,
		NULL);
	if(Read_return == FALSE ) {
		printf("read fail \n%d\n", GetLastError());
		return -1;
	}
	
	
	for (counter = 446; counter < 512; counter++) {
		Buffer[counter] = Buffer[counter + BUFF_SIZE];
	}
	Write_return = WriteFile(
		chain,
		Buffer,
		BUFF_SIZE *2,
		&Get,
		NULL);
	if(Write_return == FALSE) {
		printf("write fail \n%d\n", GetLastError());
		return -1;
	}
	printf("\nYou must know.The mbr.bak is the bak file. \nThe chainloader.bin is the file you need.\n\n ");
	printf("\n\tThe loader make successfully\n");
	CloseHandle(hDevice);
	CloseHandle(hFile );
	CloseHandle(chainloader);
	CloseHandle(chain);

	return 0;
}

#else		/*for unix like system. */
int main(int argc, char *argv[])
{
	int fd;
	int file;
	int chainloader;
	int chain;
	int counter;
	char Buffer[BUFF_SIZE * 2];
	if (argc != 2) {
		printf("Use error. Please follow next :\n\tloadermake\
/dev/diskname\n\tthe disk name is you hard disk name which in /dev.\n");
	}
	if ((fd = open(argv[1], O_RDONLY)) == EOF) {
		printf("The disk name error or you don't heave the root's power.\n");
		return -1;
	}
	if (read(fd,Buffer,BUFF_SIZE *2) != BUFF_SIZE *2) {
		printf("read the disk error.\n");
		return -1;
	}
	if ((file = creat("mbr.bak",0x755)) == EOF) {
		printf("creat file mbr.bak error.\n");
		return -1;
	}
	if (write(file, Buffer, BUFF_SIZE * 2) != BUFF_SIZE * 2) {
		printf("write file errot.\n");
		return -1;
	}
	if ((chain = creat("chainloader.bin", 0x755)) == EOF) {
		printf("creat chainloader.bin error.\n");
		return -1;
	}
	if ((chainloader = open("chainloader", O_RDONLY)) == EOF) {
		printf("open chainloader error.\n");
		return -1;
	}
	for (counter = 0; counter < 512; counter++) {
		Buffer[counter + 512] = Buffer[counter];
	}
	if (read(chainloader, Buffer, BUFF_SIZE) != BUFF_SIZE) {
		printf("read chainloader error.\n");
		return -1;
	}
	for (counter = 446; counter < 512; counter++) {
		Buffer[counter] = Buffer[counter + BUFF_SIZE];
	}
	if (write(chain, Buffer, BUFF_SIZE *2) != BUFF_SIZE *2) {
		printf("creat chainloader.bin error.\n");
		return -1;
	}
	printf("\nYou must know.The mbr.bak is the bak file. \nThe chainloader.bin is the file you need.\n\n ");
	printf("\nThe loader make successfully.\n");
	close(fd);
	close(file);
	close(chain);
	close(chainloader);
	return 0;
}
#endif