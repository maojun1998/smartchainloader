#include<windows.h>
#include<stdio.h>

#define BUFF_SIZE 512	

int main(int argc, char *argv[])

{
	int Write_return;
	int Read_return;
	char Buffer[BUFF_SIZE * 2] = {0x00};								
	DWORD Get;	
	HANDLE hDevice;
	HANDLE hFile;

	if (argc != 2) {
		printf("\tUse errot. Use the command \"WriteLoader loaderfile\"\n.\
\tThe \"loaderfile\" is the  name of file for the loader.\n\n");
		return -1;
	}

	hDevice = CreateFile(
        TEXT("\\\\.\\PHYSICALDRIVE0"),
        GENERIC_READ | GENERIC_WRITE ,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        0);
	hFile = CreateFile(
        argv[1],
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        0);	

	if (INVALID_HANDLE_VALUE ==  hDevice){
		printf("open disk fail\n%d\n", GetLastError());
		return -1;
	}
	if (INVALID_HANDLE_VALUE ==  hFile){
		printf("The loaderfile fail\n%d\n", GetLastError());
		return -1;
	}
	Read_return = ReadFile(
		hFile,
		Buffer,
		BUFF_SIZE * 2,
		&Get,
		NULL);
	
/***
		Write two secotor of the disk.
***/
	Write_return = WriteFile(
		hDevice,
		Buffer,
		BUFF_SIZE,
		&Get,
		NULL);
	if(Read_return == FALSE) {
		printf("read fail \n%d\n", GetLastError());
		return -1;
	}
	
	Read_return = WriteFile(
		hDevice,
		Buffer + BUFF_SIZE,
		BUFF_SIZE,
		&Get,
		NULL);
	if(Read_return == FALSE ) {
		printf("read fail \n%d\n", GetLastError());
		return -1;
	}
	
	printf("**Write the disk successfully.\n\
You must copy the the mbr.bak to other physical disk like USB ...\n\
Because this file can recover you systemp just use \"WriteLoader mbr.bak\"");
	CloseHandle(hDevice);
	CloseHandle(hFile );


	return 0;

}