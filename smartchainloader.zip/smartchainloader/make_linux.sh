#!/bin/sh
export base_dir=..
echo This a build srcipt for building the smart-chainloader.
cd out
nasm -f bin $base_dir/src/chainloader.asm
cp $base_dir/src/chainloader $base_dir/out
rm $base_dir/src/chainloader
gcc $base_dir/src/loadermake.c -o loadermake
echo Building finished.
